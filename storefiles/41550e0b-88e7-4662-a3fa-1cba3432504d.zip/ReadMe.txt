	##################################################
	#                 ACL Injector v1.0              #
	##################################################
	#                                                #
	#   Author  : Arnaud FRANCOIS                    #
	#   Team    : IAM Team                           #
	#   Date    : April 2013                         #
	#                                                #
	##################################################

Manual :
--------

1. This file must be copied to the site server.

2. Log on the site server using the INTEGRATION account.

3. Run the file on the server. Wait until all ACL are deployed.



Help : 
------

If any question, feel free to ask IAM team : iam@oxylane.com